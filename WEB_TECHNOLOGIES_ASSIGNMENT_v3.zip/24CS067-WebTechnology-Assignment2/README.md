# Student Admission & Management System

**U21CS501 – Web Technologies · Assignment II**
**Name:** S B GOKUL  **Roll No:** 24CS067  **Class:** III Year / V Sem / CSE – B
**Institution:** KPR Institute of Engineering and Technology, Coimbatore

One connected project that answers all three questions of the assignment. All three parts
share one MySQL database (`student_portal`), and the Servlet portal (Q3) displays the files
that were uploaded through the PHP admin panel (Q2).

| Question | Folder | Technologies |
|---|---|---|
| Q1 – Student registration form with validation | `q1-registration-form/` | HTML5, CSS3, JavaScript |
| Q2 – Admin panel: CRUD + file uploads | `q2-php-admin-panel/` | PHP 8, MySQL (MySQLi) |
| Q3 – Student profile portal with login | `q3-servlet-portal/` | Java Servlets, JSP, JDBC, Tomcat 10 |
| Database schema script | `database/schema.sql` | MySQL / MariaDB |

## Folder structure

```
24CS067-WebTechnology-Assignment2/
├── database/
│   └── schema.sql                  # creates the database, 3 tables and sample data
├── q1-registration-form/
│   ├── index.html                  # registration form
│   ├── css/style.css               # layout, colours, responsive design
│   └── js/validation.js            # client-side validation
├── q2-php-admin-panel/
│   ├── config/db.php               # MySQL connection settings
│   ├── includes/                   # functions, header, footer, shared form
│   ├── assets/css/admin.css
│   ├── uploads/                    # images/ and documents/ (+ .htaccess security)
│   ├── index.php  add.php  edit.php  view.php  delete.php  delete_file.php
├── q3-servlet-portal/
│   ├── pom.xml                     # Maven build (creates student-portal.war)
│   └── src/main/
│       ├── java/com/kpriet/portal/ # dao, filter, model, servlet, util packages
│       └── webapp/                 # css/, index.jsp, WEB-INF/web.xml, WEB-INF/views/*.jsp
└── screenshots/                    # browser output of all three questions
```

## How to run

### 1. Database
1. Start **MySQL** (for example from the XAMPP Control Panel).
2. Open phpMyAdmin → **SQL** tab, paste the contents of `database/schema.sql`, click **Go**
   (or run `mysql -u root -p < database/schema.sql`).

### 2. Q1 – Registration form
Open `q1-registration-form/index.html` in any browser. No server is needed.

### 3. Q2 – PHP admin panel
1. Copy the `q2-php-admin-panel` folder into `C:\xampp\htdocs\`.
2. If your MySQL root user has a password, set it in `config/db.php`.
3. Start **Apache** and open <http://localhost/q2-php-admin-panel/>.

### 4. Q3 – Servlet portal (Apache Tomcat 10 or 11, JDK 11+)
1. In `src/main/webapp/WEB-INF/web.xml` check:
   * `jdbcUser` / `jdbcPassword` – your MySQL login
   * `uploadBaseDir` – full path of the Q2 folder, e.g. `C:/xampp/htdocs/q2-php-admin-panel`
2. **With Maven:** `mvn clean package` → copy `target/student-portal.war` to `<tomcat>/webapps/`.
   **Without Maven (Eclipse Dynamic Web Project):** copy `src/main/java` and `src/main/webapp`
   into the project and put `mysql-connector-j-8.4.0.jar` into `WEB-INF/lib`.
3. Start Tomcat and open <http://localhost:8080/student-portal/>.
4. Log in with **admin / Admin@123**.

> Tomcat 9 or older uses the `javax.servlet` package. For Tomcat 9, replace every
> `jakarta.servlet` import with `javax.servlet` and use a Servlet 4.0 `web.xml` header.

## Main features
* **Q1:** required-field, email, roll number and phone checks; live password-strength meter;
  file type/size checks with photo preview; responsive layout for mobile screens.
* **Q2:** add / edit / view / delete students; profile image, ID proof and multiple certificate
  uploads; metadata (path, MIME type, size, date) stored in MySQL; size, extension and real
  content-type checks; unique file names (no overwriting); transactions with rollback;
  CSRF tokens and prepared statements.
* **Q3:** JDBC with a DAO layer; images and PDFs streamed by `FileStreamServlet`; JSP pages
  with loops and conditions; login filter protecting every URL; session timeout,
  session-fixation protection, HttpOnly cookie; custom error pages.

## Screenshots
See the [`screenshots/`](screenshots) folder.
